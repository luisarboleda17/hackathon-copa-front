/**
 * Created by luis_arboleda17 on 05/20/18.
 */

import API from '../../api';

/**
 * Action types
 */



/**
 * Actions
 */



/**
 * Get flights from server
 * @returns {function(*): (Q.Promise<any> | Promise<T | never>)}
 */
